#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Oct 19 14:56:57 2018

@author: Adithya
"""
#importing required packages
import sys
import math
import numpy as np
import time
from random import randint

#function to check the terminal state of the board
#completetion means selected row/column/daiagonal contains only current player
def is_terminal(state, current_player, alternate_player):
#    print("is terminal")
#    state = state_touple[0]
#    print (state)
    n = len(state) - 3 
        
    dia_list = []
    dia_list_2 = []
    state_trans = np.transpose(state)
#row check
#checking if row is complete
    for i in range(n):
#    len(set(l[i])) == 1
        if list(set(state[i])) == [current_player]:
            return True

#dia check
#checking if diagonal is complete
        dia_list.append(state[i][i])
        dia_list_2.append(state[n-i-1][i])
    if list(set(dia_list)) == [current_player]:
        return True
    if list(set(dia_list_2)) == [current_player]:
        return True    
#col check
#checking if column till n index is complete
    for j in range(len(state_trans)):
        if list(set(state_trans[j][:n])) == [current_player]:
            return True

    return "No"

#function to give successor of given state
#state touple is of form (state, height travelled so far from start node)
#player is current player
def successor(state_touple, player):
#    print ("successor")
#    print (state_touple)
    state = state_touple[0]
    succ_list = []
    n = len(state) - 3
    for i in range(n):
#taking individual rows and columns
        fun_list = np.array(state)
        fun_trans = np.transpose(np.array(state))
#checking if column already filled and whether a player has used all his allowed pebbles
#checking for bottom empty slot in coloumn and adding palyer there
        if (np.count_nonzero(fun_trans[i] == '.') != 0 and np.count_nonzero(fun_list == player) < int(n*(n+3)/2)):
            for j in range(n+3):
                if state[n+3-j-1][i] == '.':
                    fun_list[n+3-j-1][i] = player
                    succ_list.append(((fun_list, state_touple[1]+1),"adding",i))
                    break
#rotating the column if column has atleast 1 pebble
#rotating by adding last element at index 0 and taking it down to bottom most available position
        fun_trans_col_list = list(fun_trans[i])
        if list(set(fun_trans_col_list)) != ['.']:
            fun_trans_col_list.insert(0, fun_trans_col_list.pop())
            if fun_trans_col_list.count('.') > 0:
                for k in range(1,len(fun_trans_col_list)):
                    if fun_trans_col_list[k] != '.':
                        fun_trans_col_list[0], fun_trans_col_list[k-1] = fun_trans_col_list[k-1], fun_trans_col_list[0]
                        break
            if fun_trans_col_list[len(fun_trans_col_list) - 1] == '.':
                fun_trans_col_list[0], fun_trans_col_list[len(fun_trans_col_list) - 1] = fun_trans_col_list[len(fun_trans_col_list) - 1], fun_trans_col_list[0]
            fun_trans[i] = fun_trans_col_list
            succ_list.append(((np.transpose(fun_trans), state_touple[1] + 1),"rotating",i))

#returning list with sucessors touples
    return succ_list


#simple eveluation to check the no: available rows, columns, diagonals available for current player to complete the board
def evaluation(state, player):
#    print ("evaluation")
#    print (state)
#    print (player)

#no of free rows + free columns + free diagonals available to player to win the board
    n = len(state) - 3
    state_trans = np.transpose(state)
    dia_list = []
    dia_list_2 = []
    count  = 1
    for i in range(n):

#checking if row is avalable for player
#        if list(set(state[i])) == [player] or list(set(state[i])) == list(('.',player)) or list(set(state[i])) == ['.'] or list(set(state[i])) == list((player, '.')):
        if list(set(state[i])) in list(([player], list(('.',player)), list((player,'.')), ['.'])):
#            print ("row")
            count += 1
#checking if column is available to player
        if list(set(state_trans[i][:n])) in list(([player], list(('.',player)), list((player,'.')), ['.'])): 
#            print ("col")
            count += 1

#creating diagonal list to verify the evation condition
        dia_list.append(state[i][i])
        dia_list_2.append(state[n-i-1][i])

#checking is both the diagonals are available for the player
    if list(set(dia_list)) in list(([player], list(('.',player)), list((player,'.')), ['.'])):
#        print ("dia1")
        count += 1
    if list(set(dia_list_2)) in list(([player], list(('.',player)), list((player,'.')), ['.'])):
#        print ("dia2")
        count += 1
#    print ("count: " + str(count))
    return count

#More complex evaluation function which gives the weighted sum of various conditions as mention in the function
def evaluation_1(state, player):
    opp_player = 'x' if player == 'o' else 'o'
    n = len(state) - 3
    state_trans = np.transpose(state)
    dia_list = []
    dia_list_2 = []
    count  = 1
    for i in range(n):
        list_check = list(set(state[i]))
#checking if row is complete with player
        if list_check == [player]:
            count += n*n*n*n*n*n*n*n
#checking if row available for player to complete 
        elif list_check in list((list(('.',player)), list((player,'.')))):
            row_count = list(state[i]).count(player)
            if row_count > n-2:
                count += 2 * (row_count ** 3)
            else:
                count += row_count ** 2
#checking for empty row
        elif list_check == ['.']:
#            print ("row")
            count += 1

# doing the same steps for columns
        list_trans_check = list(set(state_trans[i][:n]))
#        list_trans_check = list(set(state_trans[i][-n:]))
        if list_trans_check == [player]:
            count += n*n*n*n*n*n*n*n
        elif list_trans_check in list((list(('.',player)), list((player,'.')))):
            col_count =  list(state_trans[i][:n]).count(player)
            if col_count > n-2:
                count += 2 * (col_count ** 3)
            else:
                count +=  col_count ** 2
        elif list_trans_check == ['.']:
#            print ("row")
            count += 2*1
            
# checking for consecutive player pebbles and giving high priority to critical states (states having n-1 player pebbles consequetly)
        list_check_join = "".join(list(state[i]))
        for l in range(n,1,-1):
            if player*l in list_check_join:
#                count += l ** 2
#                break
                if l > n-2:
                    count += 2 * (l ** 4)
                    break
                else:
                    count += l ** 2
                    break

# Checking for states that have "n-1" player pebbles in them and when a one single rotation can complete the board
#high priority was given to those states
        row_count = list(state[i]).count(player)
        if row_count > n - 2:
#            print (state)
#case where a single opp player pebble was present
            if opp_player in list_check_join:
                row_index = list_check_join.index(opp_player)
#for first row rotation will come from last row
                if i == 0:
                    if state[n+3-1][row_index] == player:
                        count += 2 * (row_count ** 5)
#for other rows rotation will come from row above
                else:
                    if state[i-1][row_index] == player:
                        count += 2 * (row_count ** 5)
#case where a single empty slot is availabe to complete the board
            elif '.' in list_check_join:
                row_index = list_check_join.index('.')
#                if i != n-1:
#empty slot can only be filled if below slot is filled with some pebble and by adding or by rotating pebbles along that column
                if state[i+1][row_index] != '.':
                    if (state[n+3-1][row_index] == player or np.count_nonzero(state == player) < int(n*(n+3)/2)):
                        count += 2 * (row_count ** 5)
        else:
            count += 2 * (row_count ** 2)
        
#doing the same work with each column until the limit of "n-3"
#find the max sub sequence of player pebbles in each column                
        list_trans_join = "".join(list(state_trans[i]))
        for l in range(n,1,-1):
#checking the column elements till "n" as it win condition is only measured till "n" height
            if player*l in list_trans_join[:n]:
                if l > n-2:
                    count += 2 * (l ** 5)
                    break
                else:
                    count += l ** 2
                    break
#As rotation can take take the bottom elements to top, checking whole column
            elif player*l in list_trans_join:
                if l > n-2:
                    count += 2 * (l ** 4)
                    break
                else:
                    count += l ** 2
                    break


#taking the rotated version of each column and finding the max sub sequence of player
        list_trans_rot_join =  ("".join(list(state_trans[i][-3:]))+ "".join(list(state_trans[i][:n]))).replace('.','')
        for l in range(n,1,-1):
            if player*l in list_trans_rot_join:
                if l > n-2:
                    count += 2 * (l ** 5)
                    break
                else:
                    count += l ** 2
                    break

#creating similar diagonal lists to do the same work as done for rows and columns
        dia_list.append(state[i][i])
        dia_list_2.append(state[n-i-1][i])
        dia_list_join = "".join(dia_list)
        dia_list2_join = "".join(dia_list_2)
#    print (dia_list, dia_list_2)
#checking diagonal whether it is completed or can be completed by player or is empty
    if list(set(dia_list)) == [player]:
        count += n*n*n*n*n*n*n*n
    elif list(set(dia_list)) in list(( list(('.',player)), list((player,'.')))):
        dia_count = dia_list.count(player)
        if dia_count > n-2:
            count += dia_count ** 3
        else:
            count += dia_count ** 2
    elif list(set(dia_list)) == ['.']:
        count += 1
        
    if list(set(dia_list_2)) == [player]:
        count += n*n*n*n*n*n*n*n
    elif list(set(dia_list_2)) in list((list(('.',player)), list((player,'.')))):
#        print ("dia2")
        dia_count = dia_list_2.count(player)
        if dia_count > n-2:
            count += dia_count ** 3
        else:
            count += dia_count ** 2
   
    elif list(set(dia_list_2)) == ['.']:
        count += 1
    
#checknig for critical states for diagonals and assigning large values for each such state
#state with "n-1" player pebbels along diaginal is given high priority
    for l in range(n,1,-1):
        if player*l in dia_list_join:
#states with n-1 pebbels
            if l > n-2:
#if diagonal can be completed by either rotating or adding it was given high value
                if opp_player in dia_list_join:
                    row_index   = dia_list_join.index(opp_player)
                    if row_index == 0:
                        if state[n+3-1][row_index] == player:
                            count += 2 * ((n-1) ** 5)
                            break
                    else:
                        if state[row_index-1][row_index] == player:
                            count += 2 * ((n-1) ** 5)
                            break
                
                elif '.' in dia_list_join:
                    row_index   = dia_list_join.index('.')
                    if row_index == 0:
                        if state[row_index + 1][row_index] != '.':
                            if (state[n+3-1][row_index] == player or np.count_nonzero(state == player) < int(n*(n+3)/2)):
                                count += 2 * ((n-1) ** 5)
                                break
                    else:
                        if state[row_index + 1][row_index] != '.':
                            if (state[row_index-1][row_index] == player or np.count_nonzero(state == player) < int(n*(n+3)/2)):
                                count += 2 * ((n-1) ** 5)
                                break
# if pebble count is less than "n-1" less value was given
            else:
                count += l ** 2
#            count +=  2 * (l ** 4)
                break

#similar work was done with other diagonal and similar values was assigned            
    for l in range(n,1,-1):
        if player*l in dia_list2_join:
            if l > n-2:
                if opp_player in dia_list2_join:
                    row_index   = dia_list2_join.index(opp_player)
                    if row_index == n-1:
                        if state[n+3-1][row_index] == player:
                            count += 2 * ((n-1) ** 5)
                            break
                    else:
                        if state[row_index-1][row_index] == player:
                            count += 2 * ((n-1) ** 5)
                            break
                
                elif '.' in dia_list2_join:
                    row_index   = dia_list2_join.index('.')
                    if row_index == n-1:
                        if state[1][row_index] != '.':
                            if (state[n+3-1][row_index] == player or np.count_nonzero(state == player) < int(n*(n+3)/2)):
                                count += 2 * ((n-1) ** 5)
                                break
                    else:
                        if state[row_index + 1][row_index] != '.':
                            if (state[row_index-1][row_index] == player or np.count_nonzero(state == player) < int(n*(n+3)/2)):
                                count += 2 * ((n-1) ** 5)
                                break
            else:
                count += l ** 2
                break

#returing final count as evaluation of the input state
    return count

#Evaluation caluclation function to be used in min_max algo
#given the state, current player, opposite player
#Function clauclates the evaluation value for both player and opposite player and returns theie difference
#currently using evaluation_1 (wieghted sum function) as evaluation
def evaluation_cal(state, player, opp_player):
#    return (evaluation(state, player) - evaluation(state, opp_player))
    return (evaluation_1(state, player) - evaluation_1(state, opp_player))

#min_max starts
#max function
def max_value(state_touple, alfa, beta, player, opp_player, h):
    height = state_touple[1]
    terminal = is_terminal(state_touple[0], opp_player, player)
#    print (terminal)
    if terminal == True:
        n = len(state_touple[0]) - 3
        return (n*n*n*n*n*n*n*n)
    else:
#going to min node only if height is less than the pre defined depth
        if height <= h:
#            print ("going to min")
            for succ_touple, move, col in successor(state_touple, player):
                alfa = max(alfa, min_value(succ_touple, alfa, beta, opp_player, player, h))
                if alfa >= beta:
                    return alfa
            return alfa
#caluclating the evaluation of state is height reaches pre defined depth
        else:
#            print ("height reached")
            alfa = evaluation_cal(state_touple[0], player, opp_player)
            return alfa

#min function
def min_value(state_touple, alfa, beta, opp_player, player,h):
    height  = state_touple[1]
    
    terminal = is_terminal(state_touple[0], opp_player, player)
#    print (terminal)
    if terminal == True:
        n = len(state_touple[0]) - 3
# returning in negative value as this is a min terminal
        return -(n*n*n*n*n*n*n*n)
    else:
#going to min node only if height is less than the pre defined depth
        if height <= h:
#            print ("going to max")
            for succ_touple, move, col in successor(state_touple, opp_player):
                beta = min(beta, max_value(succ_touple, alfa, beta, player, opp_player, h))
                if beta <= alfa:
                    return beta
            return beta 
#caluclating the evaluation of state is height reaches pre defined depth
        else:
#            print("height reached")
            beta = evaluation_cal(state_touple[0], opp_player, player)
#returning negative beta s this is a min state check
            return -(beta)
    
def alfa_beta(state_touple, player, opp_player, h):
#    print ("alpa beta")
    beta_list = []
    beta_greedy_value = []
    beta_value = []
    if h > 0:
        for succ, move, col in successor(state_touple, player):
            b = min_value(succ, -(math.inf), math.inf, opp_player, player, h)
#for the input state the imediate sucessors evaluation is clauclated and the final was taken by givinf 85% weightage to min-max algorithm and 15% weightage to greedy algo(when only successor was considered)
#This step was done to make sure the move by player is not helping the opposite player
            b_greedy = min_value(succ, -(math.inf), math.inf, opp_player, player, 0)
            beta_list.append((b, succ, move, col))
            beta_value.append(b)
            beta_greedy_value.append(b_greedy)
    #    print (beta_list)
        print (beta_value)
        print (beta_greedy_value)

        final_beta = []
        for b in range(len(beta_value)):
#THe state with max beta value caluclated from min_max and greedy was given as output
            final_beta.append(.85*beta_value[b] + 0.15*beta_greedy_value[b])
        
#        print (final_beta)
        
#when all the values of beta was same, I am randomly picking up the successor state rather than just giving the first sucessor all the time
        if len(set(final_beta)) == 1:
            print ("random")
            return beta_list[randint(0,len(beta_list)-1)]
        
        return (beta_list[final_beta.index(max(final_beta))])
#When depth is 0
#this is used to output greedy move when the min-max was not giving output in prescribed time
    else:
        for succ, move, col in successor(state_touple, player):
            b = min_value(succ, -(math.inf), math.inf, opp_player, player, h)
            beta_list.append((b, succ, move, col))
        return max(beta_list, key = lambda element: element[0]) 

if __name__ == '__main__':
    start = time.time()
    n = int(sys.argv[1])
#    empty_list = list([["."]*n]*(n+3))
    empty_list = [[None]*n for _ in range(n+3)]
    current_player = str(sys.argv[2])
    current_board = str(sys.argv[3])
    current_board_list = ":".join(current_board).split(":")
    time_limit = int(sys.argv[4])

    for i in range(n*(n+3)):
#        print (i)
#        print (empty_list)
#        print (current_board_list[i])
        empty_list[int(i/n)][i%n] = current_board_list[i]
#    print (current_board)
#    print (empty_list)
    current_board_array = np.array(empty_list)
    print ("input params")
    print (n,current_player, current_board_array, time_limit)
    current_board_touple = (current_board_array, 0)
    alternate_player = 'x' if current_player == 'o' else 'o'

#calulcating the max depth for min max to traverse
    height = int((time_limit)*2/n)
    print ("searching till height: " + str(height))

#giving base move (greddy move just in case if programme doesn't give output by using alpa beta)
    print ("base move(greedy move output)")
    alfa_val_0, next_board_0, move_0, col_0 = alfa_beta(current_board_touple, current_player, alternate_player, 0)
    print_board_0 = next_board_0[0].tolist()
#    print (print_board)
    p_board_0 = []
    for i in print_board_0:
        p_board_0.extend(i)
#    print ("".join(p_board))
    if move_0 == "adding":
        print ("adding")
        print (col_0+1, "".join(p_board_0))
    else:
        print ("rotating")
        print ("-"+str(col_0+1), "".join(p_board_0))

    alfa_val, next_board, move, col = alfa_beta(current_board_touple, current_player, alternate_player, height)
    end = time.time()
    print ("time taken: "+ str(end - start))
    print (alfa_val, next_board, move, col)
#    print (alfa_val_0, next_board_0, move_0, col_0)
    print_board = next_board[0].tolist()
#    print (print_board)
    p_board = []
    for i in print_board:
        p_board.extend(i)
#    print ("".join(p_board))
    if move == "adding":
        print ("adding")
        print (col+1, "".join(p_board))
    else:
        print ("rotating")
        print ("-"+str(col+1), "".join(p_board))
