#!/usr/bin/env python3
import sys

def cost_func(board,m): #Calculates the cost using possessions and position of the pieces, the following citation is for the second part of the cost function Citation:http://www.chessbin.com/post/Piece-Square-Table
	sum1=0
	if m==0:
		ch=['N','B','K','P']
	else:
		ch=['n','b','k','p']
	a=[['R',54],['N',27],['B',27],['Q',83],['K',960],['P',10],['r',-54],['n',-27],['b',-27],['q',-83],['k',-960],['p',-10]]
	for row in board:
		for column in row:
			for i in a:
				if i[0]==column:
					sum1+=i[1]
	Pawn=[[0,0,0,0,0,0,0,0],[5, 5, 5, 5, 5, 5, 5, 5],[7, 7, 14, 21, 21, 16, 7, 7],[3,  3, 7, 24, 24, 7,  3,  3],[0,  0,  0, 23, 23,  0,  0,  0],[3, -3,-7,  0,  0,-7, -3,  3],[3,7,7,-22,-22,7,7,3],[0,0,0,0,0,0,0,0]]
	knight=[[-25,-20,-10,-10,-10,-10,-20,-25],[-25,-10,  0,  0,  0,  0,-10,-25],[-20,  0, 5, 10, 10, 5,  0,-20],[-20,2,7,10,10,7,2,-20],[-20,  0, 7, 15, 15, 7,  0,-20],[-20, 2, 5, 7, 7, 5,  2,-20],[-25,-15,  0,  2,  2,  0,-15,-25],[-26,-25,-10,-15,-15,-10,-25,-26]]
	bishop=[[-20,-10,-10,-10,-10,-10,-10,-20],[-10,  0,  0,  0,  0,  0,  0,-10],[-10,  0,  5, 10, 10,  5,  0,-10],[-10,  5,  5, 10, 10,  5,  5,-10],[-10,  0, 10, 10, 10, 10,  0,-10],[-10, 10, 10, 10, 10, 10, 10,-10],[-10,  5,  0,  0,  0,  0,  5,-10],[-20,-10,-40,-10,-10,-40,-10,-20]]
	king=[[-30, -40, -40, -50, -50, -40, -40, -30],[-30, -40, -40, -50, -50, -40, -40, -30],[-30, -40, -40, -50, -50, -40, -40, -30],[-30, -40, -40, -50, -50, -40, -40, -30],[ -20, -30, -30, -40, -40, -30, -30, -20],[-10, -20, -20, -20, -20, -20, -20, -10],[20,  20,   0,   0,   0,   0,  20,  20],[20,  30,  10,   0,   0,  10,  30,  20]]
	for row in range(0,len(board)):
		for col in range(0,len(board[row])):
			if board[row][col]==ch[0]:
				sum1+=knight[row][col]
			if board[row][col]==ch[3]:
				sum1+=Pawn[row][col]
			if board[row][col]==ch[2]:
				sum1+=king[row][col]
			if board[row][col]==ch[1]:
				sum1+=bishop[row][col]

	return sum1

def rook(board,dupe,a): #Generates moves by a rook in a given scenario
	children=[]
	for row in range(0,len(dupe)):
		for column in range(0,len(board[row])):

			dupe=[[cols for cols in rows] for rows in board]
			
			if dupe[row][column]==a[0][0]:
				i=row+1
				while i<8:
					if dupe[i][column] in a[0]:
						break
					if dupe[i][column] in a[1]:
						dupe[i][column]=dupe[row][column]
						dupe[row][column]='.'
						children.append([[x for x in rows] for rows in dupe])
						flag=[i,column]
						break
					if dupe[i][column]=='.':
						dupe[i][column]=board[row][column]
						dupe[row][column]='.'
						children.append([[x for x in rows] for rows in dupe])
					dupe=[[cols for cols in rows] for rows in board]
					i=i+1
				
				dupe=[[cols for cols in rows] for rows in board]
				
				i=row-1
				while i>=0:
					if dupe[i][column] in a[0]:
						break
					if dupe[i][column] in a[1]:
						dupe[i][column]=dupe[row][column]
						dupe[row][column]='.'
						children.append([[x for x in rows] for rows in dupe])
						flag=[i,column]
						break
					if dupe[i][column]=='.':
						dupe[i][column]=board[row][column]
						dupe[row][column]='.'
						children.append([[x for x in rows] for rows in dupe])
					dupe=[[cols for cols in rows] for rows in board]
					i=i-1

				dupe=[[cols for cols in rows] for rows in board]

				i=column+1
				while i<8:
					if dupe[row][i] in a[0]:
						break
					if dupe[row][i] in a[1]:
						dupe[row][i]=dupe[row][column]
						dupe[row][column]='.'
						children.append([[x for x in rows] for rows in dupe])
						flag=[i,column]
						break
					if dupe[row][i]=='.':
						dupe[row][i]=board[row][column]
						dupe[row][column]='.'
						children.append([[x for x in rows] for rows in dupe])
					dupe=[[cols for cols in rows] for rows in board]
					i=i+1

				dupe=[[cols for cols in rows] for rows in board]

				i=column-1
				while i>=0:
					if dupe[row][i] in a[0]:
						break
					if dupe[row][i] in a[1]:
						dupe[row][i]=dupe[row][column]
						dupe[row][column]='.'
						children.append([[x for x in rows] for rows in dupe])
						flag=[i,column]
						break
					if dupe[row][i]=='.':
						dupe[row][i]=board[row][column]
						dupe[row][column]='.'
						children.append([[x for x in rows] for rows in dupe])
					dupe=[[cols for cols in rows] for rows in board]
					i=i-1
	dupe=[[cols for cols in rows] for rows in board]
	return children

def bishop(board,dupe,a): #Generates moves by a bishop in a given scenario
	children=[]
	for row in range(0,len(dupe)):
		for column in range(0,len(board[row])):
			
			if dupe[row][column]==a[0][2]:
				
				i=row+1
				j=column+1
				while i<8 and j<8:
					if dupe[i][j] in a[0]:
						break
					elif dupe[i][j] in a[1]:
						dupe[i][j]=dupe[row][column]
						dupe[row][column]='.'
						children.append([[x for x in rows] for rows in dupe])
						dupe=[[cols for cols in rows] for rows in board]
						break
					elif dupe[i][j]=='.':
						dupe[i][j]=dupe[row][column]
						dupe[row][column]='.'
					children.append([[x for x in rows] for rows in dupe])
					dupe=[[cols for cols in rows] for rows in board]
					i=i+1
					j=j+1
				
				i=row+1
				j=column-1
				while i<8 and j>=0:
					if dupe[i][j] in a[0]:
						break
					elif dupe[i][j] in a[1]:
						dupe[i][j]=dupe[row][column]
						dupe[row][column]='.'
						children.append([[x for x in rows] for rows in dupe])
						dupe=[[cols for cols in rows] for rows in board]
						break
					elif dupe[i][j]=='.':
						dupe[i][j]=dupe[row][column]
						dupe[row][column]='.'
					children.append([[x for x in rows] for rows in dupe])
					dupe=[[cols for cols in rows] for rows in board]
					i=i+1
					j=j-1
				
				i=row-1
				j=column-1
				while i>=0 and j>=0:
					if dupe[i][j] in a[0]:
						break
					elif dupe[i][j] in a[1]:
						dupe[i][j]=dupe[row][column]
						dupe[row][column]='.'
						children.append([[x for x in rows] for rows in dupe])
						dupe=[[cols for cols in rows] for rows in board]
						break
					elif dupe[i][j]=='.':
						dupe[i][j]=dupe[row][column]
						dupe[row][column]='.'
					children.append([[x for x in rows] for rows in dupe])
					dupe=[[cols for cols in rows] for rows in board]
					i=i-1
					j=j-1
				
				i=row-1
				j=column+1
				while i>=0 and j<8:
					if dupe[i][j] in a[0]:
						break
					elif dupe[i][j] in a[1]:
						dupe[i][j]=dupe[row][column]
						dupe[row][column]='.'
						children.append([[x for x in rows] for rows in dupe])
						dupe=[[cols for cols in rows] for rows in board]
						break
					elif dupe[i][j]=='.':
						dupe[i][j]=dupe[row][column]
						dupe[row][column]='.'
					children.append([[x for x in rows] for rows in dupe])
					dupe=[[cols for cols in rows] for rows in board]
					i=i-1
					j=j+1
	return children

def king(board,dupe,a): #Generates moves by a King in a given scenario
	children=[]
	for row in range(0,len(dupe)):   
		for column in range(0,len(board[row])):
			if dupe[row][column]==a[0][4]:
				mov=[[1,1],[1,0],[0,1],[-1,1],[1,-1],[-1,-1],[-1,0],[0,-1]]
				for i in mov:
					if row+i[0]<8 and row+i[0]>=0 and column+i[1]<8 and column+i[1]>=0:
						if dupe[row+i[0]][column+i[1]]=='.' or dupe[row+i[0]][column+i[1]] in a[1]:
							dupe[row+i[0]][column+i[1]]=dupe[row][column]
							dupe[row][column]='.'
							children.append([[x for x in rows] for rows in dupe])
							dupe=[[cols for cols in rows] for rows in board]
	return children
def succ(board,m): #Calculates the successors
	if m==0:
		a=[['R','N','B','Q','K','P'],['r','n','b','q','k','p']]
	elif m==1:
		a=[['r','n','b','q','k','p'],['R','N','B','Q','K','P']]
	dupe=[[cols for cols in rows] for rows in board]
	children=[]
	flag=0
	children.extend(rook(board,dupe,a))
	children.extend(bishop(board,dupe,a))
	children.extend(king(board,dupe,a))
	
	if m==0:  #queen move generation
		a[0][0]='Q'
		a[0][2]='Q'
		children.extend(rook(board,dupe,a))
		children.extend(bishop(board,dupe,a))
		a[0][0]='R'
		a[0][2]='B'
	if m==1:
		a[0][0]='q'
		a[0][2]='q'
		children.extend(rook(board,dupe,a))
		children.extend(bishop(board,dupe,a))
		a[0][0]='r'
		a[0][2]='b'


	
	
	for row in range(0,len(dupe)):   # Pawn movement generation
		for column in range(0,len(board[row])):
			#print(board)
			if dupe[row][column]==a[0][5]:
				if row+1<8:
					#print("",row," ",column)
					if column-1>=0 and dupe[row+1][column-1] in a[1]:
						dupe[row+1][column-1]=dupe[row][column]
						dupe[row][column]='.'
						children.append([[x for x in rows] for rows in dupe])
						dupe=[[cols for cols in rows] for rows in board]
					if column+1<8 and dupe[row+1][column+1] in a[1]:
						dupe[row+1][column+1]=dupe[row][column]
						dupe[row][column]='.'
						children.append([[x for x in rows] for rows in dupe])
						dupe=[[cols for cols in rows] for rows in board]
					if dupe[row+1][column]=='.':
						dupe[row+1][column]=dupe[row][column]
						dupe[row][column]='.'
						children.append([[x for x in rows] for rows in dupe])
						dupe=[[cols for cols in rows] for rows in board]
					if dupe[row+2][column]=='.' and row==1:
						dupe[row+2][column]=dupe[row][column]
						dupe[row][column]='.'
						children.append([[x for x in rows] for rows in dupe])
						dupe=[[cols for cols in rows] for rows in board]

	for row in range(0,len(dupe)): # Knight movement generation
		for column in range(0,len(board[row])):
			if dupe[row][column]==a[0][1]:
				horsey=[[2,1],[2,-1],[1,2],[1,-2],[-2,1],[-2,-1],[-1,-2],[-1,2]]
				for i in horsey:
					if row+i[0]>=0 and row+i[0]<8 and column+i[1]>=0 and column+i[1]<8 and (dupe[row+i[0]][column+i[1]] not in a[0]):
						dupe[row+i[0]][column+i[1]]=dupe[row][column]
						dupe[row][column]='.'
						children.append([[x for x in rows] for rows in dupe])
						dupe=[[cols for cols in rows] for rows in board]
	return children





#taking variables as input

w_b=str(sys.argv[1])
a=str(str(sys.argv[2]))
t=int(sys.argv[3])
m=0 #switch for black and white
if(w_b.lower()=='b'):
	m=1

a=list(a)

board=[[]]
cnt=0
index=0

for i in a:   #creating a board or a grid
	if cnt%8==0 and cnt!=0:
		board.append([])
		index+=1
	board[index].append(i)
	cnt+=1

#reversing the board to satisfy the program needs if chosen to play black
if m==1:
	board.reverse()

#print(board)
#after getting all the states from the successor function, we list the costs, find the index of the maximum cost(in this program we tend to find the maximum, it is made that way)
#using which we can find the best possible state
states=succ(board,m)
lister=[]
for k in states:
	lister.append(cost_func(k,m))
index=lister.index(max(lister))

string=states[index]
#result state stored in string variable, reversing the result again if it was black as we had reversed the input to the functions earlier to satisfy the program needs
if m==1:
	string.reverse()
#printing out the result
for i in string:
	for j in i:
		print(j,end="")
