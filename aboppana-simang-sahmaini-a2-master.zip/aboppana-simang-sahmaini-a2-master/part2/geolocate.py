#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Main approach
#--------------
#Every tweet in the test set contains specific words (w1, w2, w3 ... wN)
#P(Location | w1,w2,w3...wn) = P(location) * P(w1,w2,w3...wN | Location)/P(w1,w2,w3...wN)
#By Naive Bayes Assumption, given a class (Location in this case), all other factors / variables are independent of each other. So,
#P(Location | w1,w2,w3...wn) = P(location) * P(w1| Location)* P(w2| Location)...* P(wN| Location) / P(w1,w2,w3...wN)
#P(wN | Location) = Number of times 'wN' word has appeared in training set for all 
#tweets in that Location / Total words in all tweets of that location
#For all the locations, denominator is constant. So, for every location,
#we compute the numerator, and assign location to the tweet for which numerator is maximum.
#Computed the P(w/loc) for each word using laplace smoothing i.e. count(w,c)+1/count(c)+|V|+1 
#V be the set of words in the training set, count(w,c) is count of words in class c, count(c) is #words in class c
# for any new word not in training data the probability will be 1/count(c)+|V|+1

# design decisions
#-----------------
#added words to stoplist  with similiar proportion across locations as they make poor features
#Removing non alphabetical characters like !#$*()
#Replacing double space characters with single space
#Convert the tweets to lower case

#Problems faced
#--------------
#too many stop words are increasing the run time, we found a balance between runtime and accuracy
#For words not in training data thy are replaced with the denominator of laplace smoothing instead of 0
#tried lemmatizing the words to base forms, didnt improve the accuracy and took longer
#There are many words 70% appearing just once in the training, they havent been excluded to prevent information loss


# =============================================================================
# Importing reauired libraries
# =============================================================================
import sys
import re


# =============================================================================
# Inputs
# =============================================================================
#setting the smoothing value for laplace smoothing
smo = 2

#setting up stop words to limit the vocabulary to distinguishing words rather than common ones
#https://www.geeksforgeeks.org/removing-stop-words-nltk-python/
#https://sites.google.com/site/iamgongwei/home/sw
stopwords=['ourselves', 'hers', 'between', 'yourself', 'but', 'again', 'there',
 'about', 'once', 'during', 'out', 'very', 'having', 'with', 'they', 
 'own', 'an', 'be', 'some', 'for', 'do', 'its', 'yours', 'such', 'into', 
 'of', 'most', 'itself', 'other', 'off', 'is', 's', 'am', 'or', 'who', 
 'as', 'from', 'him', 'each', 'the', 'themselves', 'until', 'below',
 'are', 'we', 'these', 'your', 'his', 'through', 'don', 'nor', 'me',
 'were', 'her', 'more', 'himself', 'this', 'down', 'should', 'our',
 'their', 'while', 'above', 'both', 'up', 'to', 'ours', 'had', 'she',
 'all', 'no', 'when', 'at', 'any', 'before', 'them', 'same', 'and', 
 'been', 'have', 'in', 'will', 'on', 'does', 'yourselves', 'then', 
 'that', 'because', 'what', 'over', 'why', 'so', 'can', 'did', 'not',
 'now', 'under', 'he', 'you', 'herself', 'has', 'just', 'where', 'too',
 'only', 'myself', 'which', 'those', 'i','im', 'after', 'few', 'whom', 't', 
 'being', 'if', 'theirs', 'my', 'against', 'a', 'by', 'doing', 'it', 
 'how', 'further', 'was', 'here', 'than',
 'job','jobs','hiring','st','ave','opening','apply',
 'click','link','w','rd','n','new','lol','haha','a','aa','aaa','aaaa','aaaaa',
'com','ly','net','org','aahh','aarrgghh','abt','accent','accented','accents','account','accounts','acne','activities','activity','ad','add','added','adding','adds','admission','admissions','ads','afaik','affiliate','affiliates','affirmation','affirmations','aft','afternoon','ago','ahead','ain','aint','aircon','album','albums','allergies','allergy','allow','allowed','allows','alot','am','angry','announcement','announcements','annoy','annoyed','annoys','anycase','anymore','app','apparently','approve','approved','approves','apps','april','area','areas','argh','arrive','arrived','arrives','article','articles','asia','asian','ask','asked','asks','ass','asses','ate','attempt','attempting','attempts','attend','attended','attends','august','auto','autoindustry','awesome','babeh','babies','baby','back','backed','bad','bag','bags','bai','balance','bank','banks','based','bcos','bcoz','bday','bed','bedroom','belong','belonged','belongs','big','bigger','biggest','billion','billons','birthday','birthdays','bit','biz','blah','bleh','bless','blessed','blk','blog','blogcatalog','blogger','bloggers','blogging','blogs','bloody','book','bored','boring','bottle','bottles','bought','box','boxes','boy','boys','break','breakfast','breakfasts','bright','bring','brings','bro','broke','broken','bros','brought','btw','build','builds','built','bus','buses','butter','buy','buys','bye','byebye','byee','call','called','calls','cancel','canceled','cancelled','cancels','candies','candy','car','career','careers','cars','catch','catches','caught','change','changed','changes','changing','channel','channels','cheap','check','checked','checks','chicken','chickens','chocolate','chocolates','choice','choices','class','classes','click','close','closed','closes','cloth','clothe','clothes','clutter','cluttered','cna','coffee','com','comeback','comment','commenting','comments','common','companies','company','complete','completed','completes','completing','conditions','condo','condominium','condominoums','condos','congrats','congratulation','congratulations','consecutive','consecutively','consult','consultant',
'consults','contact','contacted','contacts','contd','content','contents','continue','continues','conv','cookies','cos','cost','costs','couldn','couldnt','countries','country','couple','couples','course','courses','cove','coves','coz','crap','crappy','crazy','cream','create','created','creates','creats','crowded','cum','curnews','curr','customer','customers','cute','cuties','cuz','dad','daily','damn','dark','dat','date','dated','dates','day','days','de','dead','dear','death','december','depend','depended','depends','deposit','deposited','deposits','detail','details','didn','didnt','die','died','dies','diff','dinner','dinners','dis','distract','distracted','distracts','doc','docs','document','documents','doesn','doesnt','don','dont','door','doors','double','doubled','doubles','download','downloads','dr','dreamt','drs','due','dun','dunno','duper','earlier','earliest','early','earn','earned','earns','easier','easy','eat','eaten','eats','eh','ehh','email','emails','emo','emos','enable','enables','enabling','end','ends','eng','enter','entered','enters','esp','event','events','everyday','everywhere','exclude','excluded','excludes','excuse','excused','excuses','explode','exploded','explodes','eye','eyes','fadein','fail','failed','fails','fake','fall','falls','false','families','family','famous','fast','faster','fastest','fat','favorite','favorited','favorites','favourite','favourites','featured','february','feed','feeds','feel','feeling','feels','fell','felt','female','females','ffs','finally','find','finds','finish','finished','flat','flats','flight','flights','fml','follow','followed','follows','food','form','formed','forming','forms','found','free','friday','friend','friends','fries','frm','fruit','fruits','ftl','ftw','fu','fuck','fucks','full','fully','fun','funny','furnish','furnished','future','fwah','g2g','gajshost','gave','gd','geez','gg','gift','gifted','gifts','gigs','gimme','girl','girls','give','giveaway','giveaways','given','gives','gonna','good','goodbye','goodnight','got','gotta','grats','gratz','great','greats','gtfo','gtg','guess','guessing','guy','guys',
'haa','haha','hahaha','hair','hairs','hand','hands','happen','happened','happens','hard','harder','hardest','hasn','hasnt','hate','hated','hates','hav','haven','havent','hdb','hear','heard','hears','heart','hee','heh','hehe','hehehe','hello','hey','hi','highest','hmm','ho','hohoho','holiday','holidays','home','homework','homeworks','hope','hopefully','hoping','host','hosted','hosts','hot','hour','hours','http','https','huge','huh','huhu','huhuhu','hurt','hurts','idea','ideas','idiot','idiots','idk','iirc','im','imho','imo','important','indicate','indicated','indicates','indicating','info','information','ini','install','installation','installations','installs','interact','interacted','interacting','interaction','interactions','interacts','interested','interesting','internet','introduction','introductions','involve','involved','involves',
 ]
# =============================================================================
# Data Preprocessing
# =============================================================================


def preprocess(inputlist):
    dic = {}
    loc_count ={}
    word_count = {}
    voc = []
    #https://stackoverflow.com/questions/24647400/what-is-the-best-stemming-method-in-python
    #lem = nltk.wordnet.WordNetLemmatizer()
    for i in inputlist:
        x = i.strip('\n').split(" ")
        line = re.sub('[^\w\s]+','',i.replace(x[0],"")) #remove punctuation
        line = re.sub('[^a-z\s]+',' ',line,flags=re.IGNORECASE) #remove non alphabetical char
        #line = re.sub(r"\b[a-zA-Z]\b", "", line) #removing single letters
        line = re.sub('(\s+)',' ',line)  #remove extra spaces
        line = line.lower().strip() # Converting to lower case
        
        #line = [lem.lemmatize(x) for x in line.split(" ")]
        
        a=line.split()
        if x[0] not in dic.keys():
                dic[x[0]] = []
                loc_count[x[0]] = 0
                word_count[x[0]] = {}
        #unique words in each line to a list
        voc.extend([x for x in set(a) if x not in stopwords ])
        #counting word freqencies in each tweet
        for j in a:
            if j not in stopwords:
                loc_count[x[0]]  += 1
                if j not in word_count[x[0]].keys():
                    word_count[x[0]][j] = 0
                word_count[x[0]][j] += 1
                
        dic[x[0]].append((i,a))
        #word_list_dic[x[0]] += list(filter(lambda x: x not in stopwords,filter(None,a)))
    
    #getting the unique words count 
    voc = len(set(voc))   
    return dic, word_count,loc_count,voc
        
        
# =============================================================================
# Naive Bayes
# =============================================================================
#Calculating the probabilities

def subprob(dic,wordcount,loc_count,voc):
    #getting the count of tweets
    totcnt = sum(map(len, dic.values()))
    ploc = {}
    pwordloc = {}
    pword = {}
    plocword = {}
    topfive = {}
    #Calculating p(loc) & p(word|loc) using laplace smoothing    
    for i in dic.keys():
        ploc[i] = len(dic[i]) / float(totcnt)        
        if i not in pwordloc.keys():
            pwordloc[i] = {} 
        for k in wordcount[i].keys():            
            #pwordloc[i][k] = wordcount[i][k]/float(loccnt)
            pwordloc[i][k] = (wordcount[i][k]+smo)/(loc_count[i]+ smo*voc)
    
    #getting pword sum += p(word|loc)*p(loc) over all locations
    for i in dic.keys():
        for k in wordcount[i]:
            if k not in pword.keys():
                pword[k] = 0
            pword[k] +=  pwordloc[i][k] * ploc[i]
    #getting the top prob words for each location calculate p(w|loc)*p(loc)/p(word) 
    for i in dic.keys():
        for k in wordcount[i]:
            if i not in plocword.keys():
                    plocword[i] = {} 
            #print(i,k,pwordloc[i][k],ploc[i],pword[k])        
            plocword[i][k] = pwordloc[i][k] * ploc[i] / pword[k]

    #returning the words with highest prob for each location
    # get the list of words for which the words are in tleast 1% of tweets
    top_dic = {}
    for i in  pwordloc.keys():
        #del dict
        if i not in top_dic.keys():
            top_dic[i] = {} 
        for j in pwordloc[i].keys():
            if wordcount[i][j]/float(len(wordcount[i])) > 0.01:
                top_dic[i][j] = plocword[i][j]       

    for i in  plocword.keys(): 
        if i not in topfive.keys():
                    topfive[i] = {}
        #https://stackoverflow.com/questions/7197315/5-maximum-values-in-a-python-dictionary
      
        for w in sorted(top_dic[i], key=top_dic[i].get, reverse=True)[:5]:
            #if w not in del_dic[i]:
                  topfive[i][w] = top_dic[i][w]        
    return ploc, pwordloc,pword, topfive



      
#function to return max prob location for a given tweet
def maxprobloc(tweet,ploc,pwordloc,loc_count,voc):
    q = 0
    loc = ""
    for j in pwordloc.keys():#loc        
        p = ploc[j]
        for i in tweet:
            if i in pwordloc[j].keys():
                p = p * pwordloc[j][i]
            else:
                p = p * (1/float(loc_count[j]+ smo*voc))
            #else:
            #    p = p*(1/(len(pwordloc[j])+len(pword)))
        if p > q :
            q=p
            loc = str(j)
    return loc
 

                    
#Function to store the scored location for each tweet and output the result                    
def score(dic,ploc,pwordloc,loc_count,voc):
    output = {}
    for i in dic.keys():
        if i in ploc.keys():
            if i not in output.keys():
                output[i]=[]           
            for j in dic[i]:
                output[i].append((maxprobloc(j[1],ploc,pwordloc,loc_count,voc),j[0]))
    return output

#Print & save output
def printout(p4,output):    
    for i in p4.keys():
        print(i,'\n',list(p4[i].keys()))
        
    with open('output.txt', 'w') as f:
        for i in sum(output.values(),[]):
            k = str(i[0]) + ' ' + str(i[1]) 
            f.write(k)
    
#def accuracy(output):
#    totcnt = sum(map(len, output.values()))
#    count =0
#    for i in output.keys():        
#        for j in output[i]:
#            if i == j[0]:
#                count +=1
#    return (count*100)/totcnt  
# 
# =============================================================================
# Final function calls to read, train and score the data        
# =============================================================================
#importing data
train_raw = [line for line in open(str(str(sys.argv[1])))]
test_raw = [line for line in open(str(str(sys.argv[2])))]
outputfile = str(sys.argv[3])

#call preprocessing
train_c, train_w_count,train_loc_count,train_voc = preprocess(train_raw)
test_c, test_w_count,test_loc_count,test_voc = preprocess(test_raw)

#Build the model
ploc,pwordloc,pword,topfive= subprob(train_c, train_w_count,train_loc_count,train_voc)


#print the output
printout(topfive,score(test_c,ploc,pwordloc,train_loc_count,train_voc)) 
#print(accuracy(score(test_c,ploc,pwordloc,train_loc_count,train_voc)))
del train_raw, test_raw,smo,outputfile,train_c, train_w_count,train_loc_count,train_voc,test_c, test_w_count,test_loc_count,test_voc,ploc,pwordloc,pword,topfive,stopwords
   

      





      

